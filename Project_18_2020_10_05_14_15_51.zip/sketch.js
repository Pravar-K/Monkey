var bananaImage, obstacleImage, obstacleGroup, background, score, foodGroup;

function preload(){
  backImage=loadImage("jungle.jpg");
  monkey_running = loadAnimation("Monkey_01.png","Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey_08.png", "Monkey_09.png", "Monkey_10.png");
  bananaImage=loadImage("Banana.png");
  obstacle_img=loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  var background=createSprite(200,200,20,20);
  background.addImage(backImage);
  background.velocityx=-6;
  var ground = createSprite(200,350,400,20);
  ground.visible=false;
  var monkey=createSprite(75,350,20,20);
  monkey.addImage(monkey_running);
  monkey.scale=0.2;
  var score = 0;
  var food = createSprite(400,350,20,20);
  food.addImage(bananaImage);
  food.velocityX=-6;
  foodGroup.add(food);
  var obstacles = createSprite(400,350,20,20);
  obstacles.addImage(obstacle_Img);
  obstacles.velocityX=-6;
  obstacleGroup.add(obstacles);
}

function draw() {
  background(220);
  if (background.width/2<0) { 
    background.x=200;
  }
  if(foodGroup.isTouching(monkey)){
    score=score+2;
    foodGroup.destroyEach();
  }
  switch(score){
    case 10: player.scale=0.12;
      break;
    case 20: player.scale=0.14;
      break; 
    case 30: player.scale=0.16;
      break;
    case 40: player.scale=0.18;
      break;
    default: break;
  }
  
  if (obstaclesGroup.isTouching(monkey)){
    monkey.scale=0.2;
  }
  stroke("white");
  teaxtSize("20");
  fill("white");
  text("Score: "+score,500,500);
}